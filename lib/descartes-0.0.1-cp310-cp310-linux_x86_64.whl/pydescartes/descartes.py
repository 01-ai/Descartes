# encoding=utf8
from py01ai import GraphIndex as GraphIndexWrapper


class Entity():
    def __init__(self, key=None, score=float('nan')):
        self.key = key
        self.score = score

    def __str__(self) -> str:
        return 'key:{} score:{}'.format(self.key, self.score)


class SearchContext():
    def __init__(self):
        self.topk = 10
        self.search_res_cnt = 20
        self.explore_factor = 1.0
        self._result = []

    def get_result(self) -> list[Entity]:
        return self._result


class GraphIndex():
    def __init__(self):
        self._index = GraphIndexWrapper()

    def init(self, config_path: str) -> int:
        return self._index.init(config_path)

    def add_vector(self, vector, key: int) -> int:
        return self._index.add_vector(vector, key)

    def add_vector_parallel(self, vector, threads: int) -> int:
        if threads < 0:
            raise ValueError("thread num invalid: " + str(threads))
        return self._index.add_vector_parallel(vector, threads)

    def search(self, vector, context: SearchContext) -> int:
        context.get_result().clear()
        ret, entities = self._index.search(vector, context.topk, search_res_cnt=context.search_res_cnt,
                                           explore_factor=context.explore_factor)
        for entity in entities:
            context.get_result().append(Entity(key=entity[0], score=entity[1]))
        return ret

    def refine_index(self, quantize: bool=True) -> int:
        return self._index.refine_index(quantize)

    def dump(self) -> int:
        return self._index.dump()
    
    def get_current_doc_cnt(self) -> int:
        return self._index.get_current_doc_cnt()
